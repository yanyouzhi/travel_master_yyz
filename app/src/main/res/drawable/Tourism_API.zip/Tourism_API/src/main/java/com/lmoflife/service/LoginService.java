package com.lmoflife.service;

import cn.hutool.core.util.RandomUtil;
import cn.hutool.crypto.digest.DigestUtil;
import cn.hutool.core.util.ReUtil;
import com.lmoflife.mapper.CommonMapper;
import com.lmoflife.mapper.UserMapper;
import com.lmoflife.pojo.Result;
import jakarta.annotation.Resource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Service
public class LoginService {

    private final String table = "user";
    private final String verifyTable = "verify";

    @Resource
    private CommonMapper commonMapper;

    @Resource
    private UserMapper userMapper;

    @Resource
    private JavaMailSender javaMailSender;

    @Resource
    private String mailUsername;

    public Result login(String email, String phone, String pwd) {
        if (ObjectUtils.isEmpty(pwd) || (ObjectUtils.isEmpty(email) && ObjectUtils.isEmpty(phone)))
            return Result.failed("参数错误");

        String key = !ObjectUtils.isEmpty(email) ? "email" : "phone";
        String value = !ObjectUtils.isEmpty(email) ? email : phone;

        Map<String, Object> user = commonMapper.selectData(table, key, value);
        if (ObjectUtils.isEmpty(user)) return Result.failed("未注册");

        if (!DigestUtil.md5Hex(pwd).equals(user.get("pwd"))) return Result.failed("密码错误");

        String token = generateUniqueValue("token");
        commonMapper.edit(table, "token", token, key, value);
        commonMapper.edit(table, "login", new Date(), key, value);

        return Result.success("登录成功", commonMapper.selectData(table, "token", token));
    }

    public Result signup(String email, String phone, String pwd, String verify) {
        if (ObjectUtils.isEmpty(pwd) || ObjectUtils.isEmpty(email)
                || ObjectUtils.isEmpty(phone) || ObjectUtils.isEmpty(verify))
            return Result.failed("参数错误");

        if (commonMapper.exists(table, "email", email) > 0 || commonMapper.exists(table, "phone", phone) > 0)
            return Result.failed("邮箱或手机号已注册");

        Map<String, Object> emp = userMapper.selectVerify(verify);
        if (ObjectUtils.isEmpty(emp) || !email.equals(emp.get("email"))) return Result.failed("验证码无效");

        String id = generateUniqueValue("id");
        String token = generateUniqueValue("token");

        Map<String, Object> map = new HashMap<>();
        map.put("id", id);
        map.put("name", email);
        map.put("email", email);
        map.put("phone", phone);
        map.put("pwd", DigestUtil.md5Hex(pwd));
        map.put("token", token);

        if (userMapper.insert(map) > 0)
            return Result.success("注册成功，已登录", commonMapper.selectData(table, "id", id));

        return Result.failed("失败");
    }

    public Result resetPassword(String email, String pwd, String verify) {
        if (ObjectUtils.isEmpty(pwd) || ObjectUtils.isEmpty(email) || ObjectUtils.isEmpty(verify))
            return Result.failed("参数错误");

        Map<String, Object> emp = userMapper.selectVerify(verify);
        if (ObjectUtils.isEmpty(emp) || !email.equals(emp.get("email"))) return Result.failed("验证码无效");

        if (commonMapper.edit(table, "pwd", DigestUtil.md5Hex(pwd), "email", email) > 0)
            return Result.success("成功");

        return Result.failed("失败");
    }

    public Result sendVerification(String email) {
        String ReUtilEmail = null;
        if (ObjectUtils.isEmpty(email) || !ReUtil.isMatch(ReUtilEmail, email))
            return Result.failed("邮箱错误");

        commonMapper.delete(verifyTable, "email", email);

        String code = generateUniqueVerificationCode();

        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom(mailUsername);
        message.setTo(email);
        message.setSubject("邮箱安全验证");
        message.setText("您正在进行邮箱验证，本次验证码为： " + code + "\n为了保障您帐号的安全性，请在10分钟内完成验证。");

        javaMailSender.send(message);

        String id = generateUniqueValue("id");

        Map<String, Object> map = new HashMap<>();
        map.put("id", id);
        map.put("code", code);
        map.put("email", email);

        if (userMapper.insertVerify(map) > 0)
            return Result.success("验证码已发送");

        return Result.failed("发送失败");
    }

    public Map<String, Object> getUserByToken(String token) {
        if (ObjectUtils.isEmpty(token)) return null;
        return commonMapper.selectData(table, "token", token);
    }

    // =================== 辅助函数 ===================

    private String generateUniqueValue(String field) {
        String value = RandomUtil.randomString(10);
        while (commonMapper.exists(table, field, value) > 0) {
            value = RandomUtil.randomString(10);
        }
        return value;
    }

    private String generateUniqueVerificationCode() {
        String code = RandomUtil.randomNumbers(6);
        while (commonMapper.exists(verifyTable, "code", code) > 0) {
            code = RandomUtil.randomNumbers(6);
        }
        return code;
    }
}
