package com.lmoflife.utils;

import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

@Slf4j
@Component
public class OssUtil {
    private static final String endpoint = "https://oss-cn-guangzhou.aliyuncs.com";
    private static final String accessKeyId = "LTAI5tJq5RvGhArjUm9hKp91";
    private static final String accessKeySecret = "0sx7AhFfagp68kgGUGqMJ7CXW4LucK";
    private static final String bucketName = "yanyouzhi8758";

    /**
     * 实现上传图片到OSS
     * @param multipartFile file
     * @return 返回访问路径
     */
    public String upload(MultipartFile multipartFile) throws Exception{
        // 获取上传文件的输入流
        InputStream inputStream = multipartFile.getInputStream();
        // 重命名文件,避免文件覆盖
        String fileName = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")) +"-"+ multipartFile.getOriginalFilename();
        return upload(inputStream, fileName);
    }

    /**
     * 上传流到OSS
     * @param inputStream 输入流
     * @param fileName 文件名
     * @return 访问路径
     */
    public String upload(InputStream inputStream,String fileName) {
        // 上传文件到 OSS
        OSS ossClient = new OSSClientBuilder().build(endpoint, accessKeyId, accessKeySecret);
        ossClient.putObject(bucketName,fileName,inputStream);
        // 访问路径: https://[bucketName].[endpointHost]/fileName
        // 例如: https://zifeiyu01-oss.oss-cn-fuzhou.aliyuncs.com/20240220120000-1.jpg
        String url = endpoint.split("//")[0] + "//" + bucketName + "." + endpoint.split("//")[1] + "/" + fileName;
        ossClient.shutdown();
        return url;
    }

    /**
     * base64转图片后上传流到OSS
     * @param imgData base64字符串
     * @return 访问路径
     */
    public String uploadBase64(String imgData) {
        // 获取文件扩展名
        String fileExt = "jpeg"; // 默认jpeg
        if (imgData.contains(";")){
            fileExt = imgData.split(";")[0].split("/")[1];
            imgData = imgData.split(",")[1]; //截取base64字符串
        }
        //生成随机文件名
        String fileName = UUID.randomUUID().toString().replace("-","")+"."+fileExt;
        return upload(base64StringToInputStream(imgData),fileName);
    }

    /**
     * base64转字节数组输入流
     * 不生成本地图片,可直接用于上传OSS
     */
    public static ByteArrayInputStream base64StringToInputStream(String base64String) {
        // 解码Base64字符串
        byte[] decodedBytes = Base64.decodeBase64(base64String);

        // 创建ByteArrayInputStream
        return new ByteArrayInputStream(decodedBytes);
    }

    // 测试base64转图片
    public static void main(String[] args) throws Exception {
        OssUtil ossUtil = new OssUtil();
        String s = ossUtil.uploadBase64("");
        System.out.println("访问路径:"+s);
    }

}
