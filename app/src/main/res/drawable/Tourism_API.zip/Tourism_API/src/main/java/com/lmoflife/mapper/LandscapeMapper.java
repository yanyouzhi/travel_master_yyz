package com.lmoflife.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.Map;

@Mapper
public interface LandscapeMapper {

    @Insert("insert into landscape (id,name,description,image) " +
            "values(#{id},#{name},#{description},#{image})")
    int insert(Map<String, Object> map);

    @Insert("insert into landscape_collect (uid,fid,type,comment,score) " +
            "values(#{uid},#{fid},#{type},#{comment},#{score} )")
    int insertCollect(Map<String, Object> map);

    /*@Select("<script> SELECT t1.* " +
            ",(SELECT COUNT(0) FROM landscape_collect t0 WHERE t0.fid = t1.id and t0.type = 1 and t0.uid = #{uid}) collect_my \n" +
            ",(SELECT COUNT(0) FROM landscape_collect t0 WHERE t0.fid = t1.id and t0.type = 2 and t0.uid = #{uid}) praise_my \n" +
            ",(SELECT COUNT(0) FROM landscape_collect t0 WHERE t0.fid = t1.id and t0.type = 3 and t0.uid = #{uid}) comment_my \n" +
            ",(SELECT COUNT(0) FROM landscape_collect t0 WHERE t0.fid = t1.id and t0.type = 4 and t0.uid = #{uid}) score_my \n" +

            " FROM v_landscape_collect t1 WHERE 1=1 " +
            " <when test='map.keyword != null and map.keyword != \"\" '> AND (t1.name like '%${map.keyword}%' OR t1.description like '%${map.keyword}%') </when>" +
            " <when test='map.sort != null and map.sort != \"\" '> ORDER BY RAND() </when>" +
            " </script>")
    IPage<Map<String, Object>> selectPage(Page page, Map<String, Object> map, String uid);*/

    @Select("<script> SELECT t1.* " +
            ",(SELECT COUNT(0) FROM landscape_collect t0 WHERE t0.fid = t1.id and t0.type = 1 and t0.uid = #{uid}) collect_my \n" +
            ",(SELECT COUNT(0) FROM landscape_collect t0 WHERE t0.fid = t1.id and t0.type = 2 and t0.uid = #{uid}) praise_my \n" +
            ",(SELECT COUNT(0) FROM landscape_collect t0 WHERE t0.fid = t1.id and t0.type = 3 and t0.uid = #{uid}) comment_my \n" +
            ",(SELECT COUNT(0) FROM landscape_collect t0 WHERE t0.fid = t1.id and t0.type = 4 and t0.uid = #{uid}) score_my \n" +

            " FROM v_landscape_collect t1 WHERE 1=1 " +
            " <when test='map.keyword != null and map.keyword != \"\" '> AND t1.name like '%${map.keyword}%' </when>" +
            " <when test='map.sort != null and map.sort != \"\" '> ORDER BY RAND() </when>" +
            " </script>")
    IPage<Map<String, Object>> selectPage(Page page, Map<String, Object> map, String uid);


    @Select("<script> SELECT t1.* " +
            ",(SELECT COUNT(0) FROM landscape_collect t0 WHERE t0.fid = t1.id and t0.type = 1 and t0.uid = #{uid}) collect_my \n" +
            ",(SELECT COUNT(0) FROM landscape_collect t0 WHERE t0.fid = t1.id and t0.type = 2 and t0.uid = #{uid}) praise_my \n" +
            ",(SELECT COUNT(0) FROM landscape_collect t0 WHERE t0.fid = t1.id and t0.type = 3 and t0.uid = #{uid}) comment_my \n" +
            ",(SELECT COUNT(0) FROM landscape_collect t0 WHERE t0.fid = t1.id and t0.type = 4 and t0.uid = #{uid}) score_my \n" +
            " FROM v_landscape_collect t1 WHERE t1.id = #{id} " +
            " </script>")
    Map<String, Object> selectData(String id, String uid);

    @Select("<script> SELECT t1.id,t1.uid,t1.fid,t1.time,t1.comment,t2.name,t2.photo FROM landscape_collect t1 " +
            "LEFT JOIN user t2 ON t1.uid = t2.id " +
            "WHERE t1.fid = #{fid} AND t1.type = 3 ORDER BY t1.time desc </script>")
    IPage<Map<String, Object>> selectPageComment(Page page, String fid);

    @Select("select count(0) from landscape_collect where uid = #{uid} AND fid = #{fid} AND type = #{type} ")
    int existsCollect(String uid, String fid, Integer type);

    @Delete("delete from landscape_collect where uid = #{uid} AND fid = #{fid} AND type = #{type} ")
    int deleteCollect(String uid, String fid, Integer type);

    //我关注的景点
    @Select("<script> SELECT t.* " +
            ",(SELECT COUNT(0) FROM landscape_collect t0 WHERE t0.fid = t.id and t0.type = 1 and t0.uid = #{uid}) collect_my \n" +
            ",(SELECT COUNT(0) FROM landscape_collect t0 WHERE t0.fid = t.id and t0.type = 2 and t0.uid = #{uid}) praise_my \n" +
            ",(SELECT COUNT(0) FROM landscape_collect t0 WHERE t0.fid = t.id and t0.type = 3 and t0.uid = #{uid}) comment_my \n" +
            ",(SELECT COUNT(0) FROM landscape_collect t0 WHERE t0.fid = t.id and t0.type = 4 and t0.uid = #{uid}) score_my \n" +
            " FROM ( " +
            "SELECT t1.time collectTime,t2.* FROM landscape_collect t1 \n" +
            "LEFT JOIN v_landscape_collect t2 on t2.id = t1.fid\n" +
            "WHERE t1.type = #{type} AND t1.uid = #{uid} ORDER BY t1.time DESC\n" +
            ")t </script>")
    IPage<Map<String, Object>> selectPageCollect(Page page, String uid, String type);

    //视图

    /*  v_landscape_collect

    SELECT t.*,((t.scoreNumber/t.score)/100) averageScore FROM (
      SELECT t1.*
      ,(SELECT COUNT(0) FROM landscape_collect t0 WHERE t0.fid = t1.id and t0.type = 1) collect
      ,(SELECT COUNT(0) FROM landscape_collect t0 WHERE t0.fid = t1.id and t0.type = 2) praise
      ,(SELECT COUNT(0) FROM landscape_collect t0 WHERE t0.fid = t1.id and t0.type = 3) comment
      ,(SELECT COUNT(0) FROM landscape_collect t0 WHERE t0.fid = t1.id and t0.type = 4) score
      ,(SELECT SUM(t0.score) FROM landscape_collect t0 WHERE t0.fid = t1.id and t0.type = 4) scoreNumber
       FROM landscape t1
    )t

     */
}
