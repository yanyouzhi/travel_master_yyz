package com.lmoflife.controller;

import cn.hutool.core.util.RandomUtil;
import cn.hutool.json.JSONObject;
import com.lmoflife.pojo.Result;
import com.lmoflife.utils.OssUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@Tag(name = "景点")
@Controller
@RequestMapping("landscape")
@Transactional(rollbackFor = Exception.class)
public class LandscapeController extends BaseController {

    private final String table = "landscape";
    private OssUtil ossUtil;

    @Operation(summary = "查询景点详情")
    @Parameters({
            @Parameter(name = "id", description = "景点ID", required = true),
            @Parameter(name = "uid", description = "用户ID", required = true),
            @Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true),
    })
    @GetMapping("selectData")
    @ResponseBody
    public Result selectData() {
        try {
            return Result.success(landscapeMapper.selectData(request.getParameter("id"), request.getParameter("uid")));
        } catch (Exception ignored) {
        }
        return Result.failed("查询失败");
    }

    @Operation(summary = "分页查询景点")
    @Parameters({
            @Parameter(name = "page", description = "页码", required = true, example = "1"),
            @Parameter(name = "limit", description = "数量", required = true, example = "10"),
            @Parameter(name = "uid", description = "用户ID", required = true),
            @Parameter(name = "keyword", description = "搜索关键词"),
            @Parameter(name = "sort", description = "传1表示随机排序"),
            @Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true),
    })
    @GetMapping("selectPage")
    @ResponseBody
    public Result selectPage() {
        try {
            Map<String, Object> map = new HashMap<>();
            map.put("keyword", request.getParameter("keyword"));
            map.put("sort", request.getParameter("sort"));
            return Result.success(landscapeMapper.selectPage(
                    newPage(request.getParameter("page"), request.getParameter("limit")), map, request.getParameter("uid")));
        } catch (Exception ignored) {
        }
        return Result.failed("查询失败");
    }

    @Operation(summary = "分页查询景点评论")
    @Parameters({
            @Parameter(name = "page", description = "页码", required = true, example = "1"),
            @Parameter(name = "limit", description = "数量", required = true, example = "10"),
            @Parameter(name = "fid", description = "景点ID", required = true),
            @Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true),
    })
    @GetMapping("selectPageComment")
    @ResponseBody
    public Result selectPageComment() {
        try {
            return Result.success(landscapeMapper.selectPageComment(newPage(request.getParameter("page"), request.getParameter("limit")), request.getParameter("fid")));
        } catch (Exception ignored) {
        }
        return Result.failed("查询失败");
    }

    @Operation(summary = "添加景点")
    @Parameters({@Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true)})
    @io.swagger.v3.oas.annotations.parameters.RequestBody(description = "body参数：名称：name，简介：description，图片（Base64字符串）：image", required = true)
    @PostMapping("add")
    @ResponseBody
    public Result add(@RequestBody JSONObject body) {
        try {
            final String name = body.getStr("name");
            final String description = body.getStr("description");
            final String image = body.getStr("image");

            if (ObjectUtils.isEmpty(name)) return Result.failed("参数错误");

            String id = RandomUtil.randomString(10);
            while (commonMapper.exists(table, "id", id) > 0) id = RandomUtil.randomString(10);

            // 处理 image，上传到 OSS
            String imageUrl = null;
            if (!ObjectUtils.isEmpty(image)) {
                imageUrl = ossUtil.uploadBase64(image); // 上传到 OSS，获取 URL
            }

            Map<String, Object> map = new HashMap<>();
            map.put("id", id);
            map.put("name", name);
            map.put("description", !ObjectUtils.isEmpty(description) ? description : null);
            map.put("image", !ObjectUtils.isEmpty(image) ? image : null);
            if (landscapeMapper.insert(map) > 0)
                return Result.success("添加成功");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Result.failed("添加失败");
    }

    @Operation(summary = "删除景点")
    @Parameters({
            @Parameter(name = "fid", description = "景点ID", required = true)
            , @Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true)})
    @GetMapping("delete")
    @ResponseBody
    public Result delete() {
        try {
            if (commonMapper.delete(table, "id", request.getParameter("fid")) > 0) {
                commonMapper.delete("landscape_collect", "fid", request.getParameter("fid"));
                return Result.success("成功");
            }
        } catch (Exception ignored) {
        }
        return Result.failed("失败");
    }

    @Operation(summary = "收藏景点")
    @Parameters({
            @Parameter(name = "uid", description = "用户ID", required = true),
            @Parameter(name = "fid", description = "景点ID", required = true),
            @Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true),
    })
    @GetMapping("addCollect")
    @ResponseBody
    public Result addCollect() {
        int type = 1;
        try {
            if (landscapeMapper.existsCollect(request.getParameter("uid"), request.getParameter("fid"), type) < 1) {
                Map<String, Object> map = new HashMap<>();
                map.put("uid", request.getParameter("uid"));
                map.put("fid", request.getParameter("fid"));
                map.put("type", type);
                map.put("comment", null);
                map.put("score", null);
                if (landscapeMapper.insertCollect(map) > 0)
                    return Result.success("成功");
            }
        } catch (Exception ignored) {
        }
        return Result.failed("失败");
    }

    @Operation(summary = "点赞景点")
    @Parameters({
            @Parameter(name = "uid", description = "用户ID", required = true),
            @Parameter(name = "fid", description = "景点ID", required = true),
            @Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true),
    })
    @GetMapping("addPraise")
    @ResponseBody
    public Result addPraise() {
        int type = 2;
        try {
            if (landscapeMapper.existsCollect(request.getParameter("uid"), request.getParameter("fid"), type) < 1) {
                Map<String, Object> map = new HashMap<>();
                map.put("uid", request.getParameter("uid"));
                map.put("fid", request.getParameter("fid"));
                map.put("type", type);
                map.put("comment", null);
                map.put("score", null);
                if (landscapeMapper.insertCollect(map) > 0)
                    return Result.success("成功");
            }
        } catch (Exception ignored) {
        }
        return Result.failed("失败");
    }

    @Operation(summary = "景点评论")
    @Parameters({
            @Parameter(name = "uid", description = "用户ID", required = true),
            @Parameter(name = "fid", description = "景点ID", required = true),
            @Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true),
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(description = "body参数：评论内容：comment", required = true)
    @PostMapping("addComment")
    @ResponseBody
    public Result addComment(@RequestBody JSONObject body) {
        int type = 3;
        try {
            Map<String, Object> map = new HashMap<>();
            map.put("uid", request.getParameter("uid"));
            map.put("fid", request.getParameter("fid"));
            map.put("type", type);
            map.put("comment", body.getStr("comment"));
            map.put("score", null);
            if (landscapeMapper.insertCollect(map) > 0)
                return Result.success("成功");
        } catch (Exception ignored) {
        }
        return Result.failed("失败");
    }

    @Operation(summary = "景点打分")
    @Parameters({
            @Parameter(name = "uid", description = "用户ID", required = true),
            @Parameter(name = "fid", description = "景点ID", required = true),
            @Parameter(name = "score", description = "分数", required = true),
            @Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true),
    })
    @GetMapping("addScore")
    @ResponseBody
    public Result addScore() {
        int type = 4;
        try {
            if (landscapeMapper.existsCollect(request.getParameter("uid"), request.getParameter("fid"), type) < 1) {
                Map<String, Object> map = new HashMap<>();
                map.put("uid", request.getParameter("uid"));
                map.put("fid", request.getParameter("fid"));
                map.put("type", type);
                map.put("comment", null);
                map.put("score", Double.parseDouble(request.getParameter("score")) * 100);
                if (landscapeMapper.insertCollect(map) > 0)
                    return Result.success("成功");
            }
        } catch (Exception ignored) {
        }
        return Result.failed("失败");
    }

    @Operation(summary = "取消收藏景点")
    @Parameters({
            @Parameter(name = "uid", description = "用户ID", required = true),
            @Parameter(name = "fid", description = "景点ID", required = true),
            @Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true),
    })
    @GetMapping("delCollect")
    @ResponseBody
    public Result delCollect() {
        int type = 1;
        try {
            if (landscapeMapper.existsCollect(request.getParameter("uid"), request.getParameter("fid"), type) > 0) {

                if (landscapeMapper.deleteCollect(request.getParameter("uid"), request.getParameter("fid"), type) > 0)
                    return Result.success("成功");
            }
        } catch (Exception ignored) {
        }
        return Result.failed("失败");
    }

    @Operation(summary = "取消点赞景点")
    @Parameters({
            @Parameter(name = "uid", description = "用户ID", required = true),
            @Parameter(name = "fid", description = "景点ID", required = true),
            @Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true),
    })
    @GetMapping("delPraise")
    @ResponseBody
    public Result delPraise() {
        int type = 2;
        try {
            if (landscapeMapper.existsCollect(request.getParameter("uid"), request.getParameter("fid"), type) > 0) {
                if (landscapeMapper.deleteCollect(request.getParameter("uid"), request.getParameter("fid"), type) > 0)
                    return Result.success("成功");
            }
        } catch (Exception ignored) {
        }
        return Result.failed("失败");
    }

    @Operation(summary = "分页查询收藏的景点")
    @Parameters({
            @Parameter(name = "page", description = "页码", required = true, example = "1"),
            @Parameter(name = "limit", description = "数量", required = true, example = "10"),
            @Parameter(name = "uid", description = "用户ID", required = true),
            @Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true),
    })
    @GetMapping("selectPageCollect")
    @ResponseBody
    public Result selectPageCollect() {
        try {
            return Result.success(landscapeMapper.selectPageCollect(newPage(request.getParameter("page"), request.getParameter("limit")), request.getParameter("uid"), "1"));
        } catch (Exception ignored) {
        }
        return Result.failed("查询失败");
    }

    @Operation(summary = "分页查询点赞的景点")
    @Parameters({
            @Parameter(name = "page", description = "页码", required = true, example = "1"),
            @Parameter(name = "limit", description = "数量", required = true, example = "10"),
            @Parameter(name = "uid", description = "用户ID", required = true),
            @Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true),
    })
    @GetMapping("selectPagePraise")
    @ResponseBody
    public Result selectPagePraise() {
        try {
            return Result.success(landscapeMapper.selectPageCollect(newPage(request.getParameter("page"), request.getParameter("limit")), request.getParameter("uid"), "2"));
        } catch (Exception ignored) {
        }
        return Result.failed("查询失败");
    }

}
