package com.lmoflife.pojo;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

/**
 * 操作结果集
 */
@Schema(description = "响应返回数据对象，响应码：200（成功），400（失败），4001（未登录），4003（未授权）")
public class Result implements Serializable {

    private static final int SUCCESS = 200;//成功
    private static final int FAILED = 400;//失败
    private static final int NOT_LOGIN = 4001;//未登录
    private static final int NOT_PERMISSION = 4003;//未授权

    @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
    private int code;

    private String msg;
    private Object data;

    public Result(int code, String failed, Object o) {
        this.code = code;
        this.msg = failed;
        this.data = o;
    }

    /**
     * 成功
     *
     * @return
     */
    public static Result success() {
        return Result.define(SUCCESS, "成功");
    }

    /**
     * 成功
     *
     * @param msg
     * @return
     */
    public static Result success(String msg) {
        return Result.define(SUCCESS, msg);
    }

    /**
     * 成功
     *
     * @param data
     * @return
     */
    public static Result success(Object data) {
        return Result.define(SUCCESS, "成功", data);
    }

    /**
     * 成功
     *
     * @param msg
     * @param data
     * @return
     */
    public static Result success(String msg, Object data) {
        return Result.define(SUCCESS, msg, data);
    }

    /**
     * 未登录
     *
     * @return
     */
    public static Result notLogin() {
        return Result.define(NOT_LOGIN, "未登录");
    }

    /**
     * 未授权
     *
     * @return
     */
    public static Result notPermission() {
        return Result.define(NOT_PERMISSION, "未授权");
    }

    /**
     * 失败
     *
     * @return
     */
    public static Result failed() {
        return Result.define(FAILED, "失败");
    }

    /**
     * 失败
     *
     * @param msg
     * @return
     */
    public static Result failed(String msg) {
        return Result.define(FAILED, msg);
    }

    /**
     * 失败
     *
     * @param data
     * @return
     */
    public static Result failed(Object data) {
        return Result.define(FAILED, "失败", data);
    }

    /**
     * 失败
     *
     * @param msg
     * @param data
     * @return
     */
    public static Result failed(String msg, Object data) {
        return Result.define(FAILED, msg, data);
    }

    private static Result define(int code, String msg) {
        return new Result(code, msg, null);
    }

    private static Result define(int code, String msg, Object data) {
        return new Result(code, msg, data);
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }


}
