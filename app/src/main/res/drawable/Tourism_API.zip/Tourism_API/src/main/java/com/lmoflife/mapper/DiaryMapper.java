package com.lmoflife.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.apache.ibatis.annotations.*;

import java.util.List;
import java.util.Map;

@Mapper
public interface DiaryMapper {

    @Insert("insert into diary (id,uid,description,image,community) " +
            "values(#{id},#{uid},#{description},#{image},#{community})")
    int insert(Map<String, Object> map);

    @Insert("insert into diary_collect (uid,fid,type,comment) " +
            "values(#{uid},#{fid},#{type},#{comment})")
    int insertCollect(Map<String, Object> map);

    @Select("<script> SELECT t1.*,t2.name,t2.photo,t2.sex,t2.addr,t2.occupation " +
            ",(SELECT COUNT(0) FROM diary_collect t0 WHERE t0.fid = t1.id and t0.type = 1) praise\n" +
            ",(SELECT COUNT(0) FROM diary_collect t0 WHERE t0.fid = t1.id and t0.type = 2) comment\n" +
            ",(SELECT COUNT(0) FROM diary_collect t0 WHERE t0.fid = t1.id and t0.type = 1 and t0.uid = #{uid}) praise_my\n" +
            ",(SELECT COUNT(0) FROM diary_collect t0 WHERE t0.fid = t1.id and t0.type = 2 and t0.uid = #{uid}) comment_my\n" +
            "FROM diary t1\n" +
            "LEFT JOIN user t2 on t2.id = t1.uid\n" +
            "WHERE 1=1 " +
            " <when test='fid != null and fid != \"\" and fid != \"null\" '> AND t1.uid = #{fid} </when>" +
            " <when test='community != null and community != \"\" '> AND t1.community = #{community} </when>" +
            " ORDER BY t1.time DESC </script>")
    IPage<Map<String, Object>> selectPage(Page page, String uid, String fid, String community);

    @Select("<script> " +
            "SELECT t1.*, t2.name, t2.photo, t2.sex, t2.addr, t2.occupation, " +
            "(SELECT COUNT(0) FROM diary_collect t0 WHERE t0.fid = t1.id AND t0.type = 1) praise, " +
            "(SELECT COUNT(0) FROM diary_collect t0 WHERE t0.fid = t1.id AND t0.type = 2) comment, " +
            "(SELECT COUNT(0) FROM diary_collect t0 WHERE t0.fid = t1.id AND t0.type = 1 AND t0.uid = #{uid}) praise_my, " +
            "(SELECT COUNT(0) FROM diary_collect t0 WHERE t0.fid = t1.id AND t0.type = 2 AND t0.uid = #{uid}) comment_my " +
            "FROM diary t1 " +
            "LEFT JOIN user t2 ON t2.id = t1.uid " +
            "WHERE t1.community = 1 " +  // 社区动态
            "ORDER BY RAND() " +         // 随机排序
            "LIMIT 9 " +                // 限制条数
            "</script>")
    List<Map<String, Object>> selectRandomCommunityList(@Param("uid") String uid);


    @Select("<script> SELECT t1.* FROM diary t1\n" +
            "WHERE t1.community = 1 " +
            " ORDER BY t1.time DESC </script>")
    IPage<Map<String, Object>> selectPage_2(Page page);

    @Select("<script> " +
            "SELECT t1.*, t2.name, t2.photo, t2.sex, t2.addr, t2.occupation, " +
            "(SELECT COUNT(0) FROM diary_collect t0 WHERE t0.fid = t1.id AND t0.type = 1) AS praise, " +
            "(SELECT COUNT(0) FROM diary_collect t0 WHERE t0.fid = t1.id AND t0.type = 2) AS comment, " +
            "(CASE WHEN #{uid} IS NOT NULL AND #{uid} != '' " +
            "      THEN (SELECT COUNT(0) FROM diary_collect t0 WHERE t0.fid = t1.id AND t0.type = 1 AND t0.uid = #{uid}) " +
            "      ELSE 0 " +
            " END) AS praise_my, " +
            "(CASE WHEN #{uid} IS NOT NULL AND #{uid} != '' " +
            "      THEN (SELECT COUNT(0) FROM diary_collect t0 WHERE t0.fid = t1.id AND t0.type = 2 AND t0.uid = #{uid}) " +
            "      ELSE 0 " +
            " END) AS comment_my " +
            "FROM diary t1 " +
            "LEFT JOIN user t2 ON t2.id = t1.uid " +
            "WHERE t1.community = 1 " +
            "ORDER BY t1.time DESC " +
            "</script>")
    IPage<Map<String, Object>> selectPage_3(Page page, String uid);


    @Select("<script> SELECT t1.*,t2.name,t2.photo,t2.sex,t2.addr,t2.occupation " +
            ",(SELECT COUNT(0) FROM diary_collect t0 WHERE t0.fid = t1.id and t0.type = 1) praise\n" +
            ",(SELECT COUNT(0) FROM diary_collect t0 WHERE t0.fid = t1.id and t0.type = 2) comment\n" +
            ",(SELECT COUNT(0) FROM diary_collect t0 WHERE t0.fid = t1.id and t0.type = 1 and t0.uid = #{uid}) praise_my\n" +
            ",(SELECT COUNT(0) FROM diary_collect t0 WHERE t0.fid = t1.id and t0.type = 2 and t0.uid = #{uid}) comment_my\n" +
            "FROM diary t1\n" +
            "LEFT JOIN user t2 on t2.id = t1.uid\n" +
            "WHERE t1.id = #{id} " +
            " </script>")
    Map<String, Object> selectData(String id, String uid);

    @Select("<script> SELECT t1.id,t1.uid,t1.fid,t1.time,t1.comment,t2.name,t2.photo FROM diary_collect t1 " +
            "LEFT JOIN user t2 ON t1.uid = t2.id " +
            "WHERE t1.fid = #{fid} AND t1.type = 2 ORDER BY t1.time desc </script>")
    IPage<Map<String, Object>> selectPageComment(Page page, String fid);

    @Select("select count(0) from diary_collect where uid = #{uid} AND fid = #{fid} AND type = #{type} ")
    int existsCollect(String uid, String fid, Integer type);

    @Delete("delete from diary_collect where uid = #{uid} AND fid = #{fid} AND type = #{type} ")
    int deleteCollect(String uid, String fid, Integer type);

}
