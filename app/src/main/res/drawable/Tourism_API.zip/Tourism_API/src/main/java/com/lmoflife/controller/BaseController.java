package com.lmoflife.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.lmoflife.mapper.CommonMapper;
import com.lmoflife.mapper.DiaryMapper;
import com.lmoflife.mapper.LandscapeMapper;
import com.lmoflife.mapper.UserMapper;
import jakarta.annotation.Resource;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.ObjectUtils;
import org.springframework.web.client.RestTemplate;

public class BaseController {

    public final String ReUtilPhone = "^1[3-9]\\d{9}$";
    public final String ReUtilEmail = "^\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*$";

    @Value("${dso.cookieName}")
    public String cookieName;

    @Value("${spring.mail.username}")
    public String mailUsername;

    @Resource
    public HttpServletRequest request;

    @Resource
    public HttpServletResponse response;

    public RestTemplate restTemplate = new RestTemplate();

    @Resource
    public CommonMapper commonMapper;

    @Resource
    public UserMapper userMapper;

    @Resource
    LandscapeMapper landscapeMapper;

    @Resource
    DiaryMapper diaryMapper;

    public Page newPage(String page, String limit) {
        int p = 1;
        int s = 10;
        if (!ObjectUtils.isEmpty(page)) p = Integer.parseInt(page);
        if (!ObjectUtils.isEmpty(limit)) s = Integer.parseInt(limit);
        return new Page<>(p, s);
    }

}
