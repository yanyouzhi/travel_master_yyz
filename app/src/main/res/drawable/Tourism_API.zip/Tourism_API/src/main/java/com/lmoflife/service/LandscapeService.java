package com.lmoflife.service;

import cn.hutool.core.util.RandomUtil;
import cn.hutool.json.JSONObject;
import com.lmoflife.mapper.CommonMapper;
import com.lmoflife.mapper.LandscapeMapper;
import com.lmoflife.utils.OssUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.util.HashMap;
import java.util.Map;

@Service
public class LandscapeService {

    @Autowired
    private LandscapeMapper landscapeMapper;

    @Autowired
    private CommonMapper commonMapper;

    @Autowired
    private OssUtil ossUtil;

    private final String table = "landscape";

    public Map<String, Object> buildLandscapeData(JSONObject body) {
        String name = body.getStr("name");
        String description = body.getStr("description");
        String image = body.getStr("image");

        if (ObjectUtils.isEmpty(name)) return null;

        String id = RandomUtil.randomString(10);
        while (commonMapper.exists(table, "id", id) > 0) {
            id = RandomUtil.randomString(10);
        }

        String imageUrl = null;
        if (!ObjectUtils.isEmpty(image)) {
            imageUrl = ossUtil.uploadBase64(image);
        }

        Map<String, Object> map = new HashMap<>();
        map.put("id", id);
        map.put("name", name);
        map.put("description", !ObjectUtils.isEmpty(description) ? description : null);
        map.put("image", imageUrl != null ? imageUrl : null);

        return map;
    }

    public boolean insertLandscape(Map<String, Object> landscapeData) {
        return landscapeMapper.insert(landscapeData) > 0;
    }

    public boolean existsCollect(String uid, String fid, int type) {
        return landscapeMapper.existsCollect(uid, fid, type) > 0;
    }

    public boolean insertCollect(String uid, String fid, int type, String comment, Double score) {
        Map<String, Object> map = new HashMap<>();
        map.put("uid", uid);
        map.put("fid", fid);
        map.put("type", type);
        map.put("comment", comment);
        map.put("score", score);
        return landscapeMapper.insertCollect(map) > 0;
    }

    public boolean deleteCollect(String uid, String fid, int type) {
        return landscapeMapper.deleteCollect(uid, fid, type) > 0;
    }
}
