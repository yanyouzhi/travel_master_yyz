package com.lmoflife.mapper;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.io.Serializable;
import java.util.Map;

@Mapper
public interface CommonMapper {

    //查询是否存在
    @Select("select count(0) from ${table} where ${field} = #{id} ")
    Long exists(String table, String field, Serializable id);

    @Select("select * from ${table} where ${field} = #{id} limit 1 ")
    Map<String, Object> selectData(String table, String field, Serializable id);

    @Delete("delete from ${table} where ${field} = #{id} ")
    int delete(String table, String field, Serializable id);

    @Update("update ${table} set ${field} = #{value} where ${column} = #{id} ")
    int edit(String table, String field, Serializable value, String column, Serializable id);


}
