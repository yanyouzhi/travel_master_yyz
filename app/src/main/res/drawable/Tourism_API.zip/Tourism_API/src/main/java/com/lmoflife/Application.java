package com.lmoflife;

import com.baomidou.mybatisplus.extension.plugins.MybatisPlusInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.BlockAttackInnerInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.OptimisticLockerInnerInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.PaginationInnerInterceptor;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SpringBootApplication
@EnableTransactionManagement
public class Application extends SpringBootServletInitializer {
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    @Bean
    public MybatisPlusInterceptor mybatisPlusInterceptor() {
        MybatisPlusInterceptor interceptor = new MybatisPlusInterceptor();

        interceptor.addInnerInterceptor(new OptimisticLockerInnerInterceptor());//乐观锁插件(确保在更新记录时，该记录未被其他事务修改)
        //interceptor.addInnerInterceptor(new IllegalSQLInnerInterceptor());//SQL非法SQL拦截插件
        //interceptor.addInnerInterceptor(new DataChangeRecorderInnerInterceptor());//数据变动记录插件

        interceptor.addInnerInterceptor(new BlockAttackInnerInterceptor());//防全表更新与删除插件
        interceptor.addInnerInterceptor(new PaginationInnerInterceptor());// 如果配置多个插件, 切记分页最后添加
        return interceptor;
    }

}
