package com.lmoflife.config;

import com.lmoflife.pojo.Result;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 统一异常处理
 */
@ControllerAdvice
public class ExceptionAdvice {

    @ExceptionHandler(Exception.class)
    @ResponseBody
    public Object errorHandler(Exception e) {
        e.printStackTrace();
        return Result.failed("服务器错误");
    }

}
