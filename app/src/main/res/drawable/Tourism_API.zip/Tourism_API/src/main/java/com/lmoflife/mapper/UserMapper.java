package com.lmoflife.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.apache.ibatis.annotations.*;

import java.util.Map;

@Mapper
public interface UserMapper {

    @Insert("insert into user (id,name,email,phone,pwd,token) " +
            "values(#{id},#{name},#{email},#{phone},#{pwd},#{token})")
    int insert(Map<String, Object> map);

    @Update("update user set name = #{name},photo = #{photo}" +
            ",sex = #{sex},addr = #{addr},description = #{description}" +
            ",occupation = #{occupation},contact = #{contact} where id = #{uid} ")
    int editUserInfo(Map<String, Object> map);

    @Insert("insert into verify (id,code,email) " +
            "values(#{id},#{code},#{email})")
    int insertVerify(Map<String, Object> map);

    @Select("select * from verify where code = #{code} limit 1 ")
    Map<String, Object> selectVerify(String code);

    @Select("<script> SELECT t1.time,t2.name,t2.id,t2.photo FROM user_collect t1\n" +
            "LEFT JOIN user t2 ON t2.id = t1.uid\n" +
            "WHERE t1.fid = #{uid} ORDER BY t1.time DESC </script>")
    IPage<Map<String, Object>> selectPageCollect(Page page, String uid);

    @Select("<script> SELECT t1.time,t2.name,t2.id,t2.photo FROM user_collect t1\n" +
            "LEFT JOIN user t2 ON t2.id = t1.fid\n" +
            "WHERE t1.uid = #{uid} ORDER BY t1.time DESC </script>")
    IPage<Map<String, Object>> selectPageFan(Page page, String uid);

    @Select("<script> SELECT t1.* " +
            ",(SELECT COUNT(0) FROM user_collect t0 WHERE t0.fid = t1.id ) collect\n" +
            ",(SELECT COUNT(0) FROM user_praise t0 WHERE t0.fid = t1.id ) praise\n" +
            ",(SELECT COUNT(0) FROM user_collect t0 WHERE t0.uid = t1.id ) collect_be\n" +
            ",(SELECT COUNT(0) FROM user_praise t0 WHERE t0.uid = t1.id ) praise_be\n" +
            ",(SELECT COUNT(0) FROM user_collect t0 WHERE t0.uid = t1.id and t0.fid = #{uid}) collect_my \n" +
            ",(SELECT COUNT(0) FROM user_praise t0 WHERE t0.uid = t1.id and t0.fid = #{uid}) praise_my \n" +

            ",(SELECT COUNT(0) FROM diary t0 WHERE t0.uid = t1.id ) diary_number " +
            ",(SELECT COUNT(0) FROM diary_collect t0 WHERE t0.uid = t1.id AND t0.type = 1 ) praise_diary_number " +
            ",(SELECT COUNT(0) FROM diary_collect t0 WHERE t0.uid = t1.id AND t0.type = 2 ) comment_diary_number " +
            ",(SELECT COUNT(0) FROM landscape_collect t0 WHERE t0.uid = t1.id AND t0.type = 1 ) collect_landscape_number " +
            ",(SELECT COUNT(0) FROM landscape_collect t0 WHERE t0.uid = t1.id AND t0.type = 2 ) praise_landscape_number " +
            ",(SELECT COUNT(0) FROM landscape_collect t0 WHERE t0.uid = t1.id AND t0.type = 3 ) comment_landscape_number " +
            ",(SELECT COUNT(0) FROM landscape_collect t0 WHERE t0.uid = t1.id AND t0.type = 4 ) score_landscape_number " +

            "FROM user t1 WHERE t1.id = #{id} </script>")
    Map<String, Object> selectData(String id, String uid);

    @Insert("INSERT INTO user_collect (fid, uid) VALUES (#{fid}, #{uid})")
    int followUser(@Param("fid") String fid, @Param("uid") String uid);

    @Update("DELETE FROM user_collect WHERE fid = #{fid} AND uid = #{uid}")
    int unfollowUser(@Param("fid") String fid, @Param("uid") String uid);

    @Select("SELECT COUNT(0) FROM user_collect WHERE fid = #{fid} AND uid = #{uid}")
    int isFollowing(@Param("fid") String fid, @Param("uid") String uid);


}
