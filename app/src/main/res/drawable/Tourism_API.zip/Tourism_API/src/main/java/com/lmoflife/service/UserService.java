package com.lmoflife.service;

import org.apache.catalina.User;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class UserService {

    // 查询用户信息
    public Map<String, Object> getUserInfo(String id, String uid) {
        // 模拟调用 Mapper 查询用户信息
        return null;
    }

    // 修改用户密码
    public boolean updatePassword(String uid, String oldPwd, String newPwd) {
        // 模拟密码校验与更新
        return false;
    }

    // 修改用户手机号
    public boolean updatePhone(String uid, String phone) {
        // 模拟手机号唯一性检查与更新
        return false;
    }

    // 修改用户邮箱
    public boolean updateEmail(String uid, String email, String verifyCode) {
        // 模拟验证码校验与邮箱更新
        return false;
    }

    // 修改用户资料
    public boolean updateUserInfo(User user) {
        // 模拟 OSS 上传 + 用户信息更新
        return false;
    }

    // 关注用户
    public boolean followUser(String uid, String fid) {
        // 模拟关注逻辑
        return false;
    }

    // 取消关注
    public boolean unfollowUser(String uid, String fid) {
        // 模拟取消关注逻辑
        return false;
    }

    // 获取我关注的用户分页
    public List<Map<String, Object>> getMyFollows(int page, int limit, String uid) {
        return null;
    }

    // 获取关注我的用户分页
    public List<Map<String, Object>> getMyFans(int page, int limit, String uid) {
        return null;
    }
}
