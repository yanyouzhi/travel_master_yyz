package com.lmoflife.controller;

import cn.hutool.core.util.RandomUtil;
import cn.hutool.json.JSONObject;
import com.lmoflife.pojo.Result;
import com.lmoflife.utils.OssUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Tag(name = "动态")
@Controller
@RequestMapping("diary")
@Transactional(rollbackFor = Exception.class)
@Slf4j
public class DiaryController extends BaseController {

    private final String table = "diary";
    // 或者使用构造器注入（推荐）
    private final OssUtil ossUtil;
    public DiaryController(OssUtil ossUtil) {
        this.ossUtil = ossUtil;
    }

    @Operation(summary = "添加动态")
    @Parameters({@Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true),})
    @io.swagger.v3.oas.annotations.parameters.RequestBody(description = "body参数：用户ID：uid，内容：description，图片（Base64字符串）：image，推送社区（1：推送，0不推送）：community", required = true)
    @PostMapping("add")
    @ResponseBody
    public Result add(@RequestBody JSONObject body) {
        try {
            if (ObjectUtils.isEmpty(body.getStr("uid"))
                    || ObjectUtils.isEmpty(body.getStr("description"))
                    || ObjectUtils.isEmpty(body.getStr("community")))
                return Result.failed("参数错误");

            String id = RandomUtil.randomString(10);
            while (commonMapper.exists(table, "id", id) > 0) id = RandomUtil.randomString(10);

            // 处理 image，上传到 OSS
            String image = body.getStr("image");
            System.out.println(image);
            String imageUrl = null;
            if (!ObjectUtils.isEmpty(image)) {
                imageUrl = ossUtil.uploadBase64(image); // 上传到 OSS，获取 URL
            }

            // 替换 image 字段为 OSS URL
            body.set("id", id);
            body.set("image", imageUrl); // 存入 OSS URL

            if (diaryMapper.insert(body) > 0)
                return Result.success("添加成功");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Result.failed("添加失败");
    }

    @Operation(summary = "删除动态")
    @Parameters({
            @Parameter(name = "fid", description = "动态ID", required = true)
            , @Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true)})
    @GetMapping("delete")
    @ResponseBody
    public Result delete() {
        try {
            if (commonMapper.delete(table, "id", request.getParameter("fid")) > 0) {
                commonMapper.delete("diary_collect", "fid", request.getParameter("fid"));
                return Result.success("成功");
            }
        } catch (Exception ignored) {
        }
        return Result.failed("失败");
    }

    @Operation(summary = "查询动态详情")
    @Parameters({
            @Parameter(name = "id", description = "动态ID", required = true),
            @Parameter(name = "uid", description = "用户ID", required = true),
            @Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true),
    })
    @GetMapping("selectData")
    @ResponseBody
    public Result selectData() {
        try {
            String id = request.getParameter("id");
            String uid = request.getParameter("uid");

            System.out.println("传入的参数：id = " + id + ", uid = " + uid);
            Map<String, Object> data = diaryMapper.selectData(id, uid);

            // 打印 praise_my 的值
            System.out.println("praise_my: " + data.get("praise_my"));
            return Result.success(diaryMapper.selectData(request.getParameter("id"), request.getParameter("uid")));
        } catch (Exception ignored) {
        }
        return Result.failed("查询失败");
    }

    @Operation(summary = "分页查询动态")
    @Parameters({
            @Parameter(name = "page", description = "页码", required = true, example = "1"),
            @Parameter(name = "limit", description = "数量", required = true, example = "10"),
            @Parameter(name = "uid", description = "登录用户ID", required = true),
            @Parameter(name = "fid", description = "用户ID（查该用户动态）"),
            @Parameter(name = "community", description = "社区动态（1是，0否）"),
            @Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true),
    })
    @GetMapping("selectPage")
    @ResponseBody
    public Result selectPage() {
        try {
            return Result.success(diaryMapper.selectPage(
                    newPage(request.getParameter("page"), request.getParameter("limit"))
                    , request.getParameter("uid"), request.getParameter("fid"), request.getParameter("community")));
        } catch (Exception ignored) {
        }
        return Result.failed("查询失败");
    }

    @Operation(summary = "分页查询动态")
    @Parameters({
            @Parameter(name = "page", description = "页码", required = true, example = "1"),
            @Parameter(name = "limit", description = "数量", required = true, example = "10"),
            @Parameter(name = "uid", description = "登录用户ID"),
            @Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true),
    })
    @GetMapping("selectPage_2")
    @ResponseBody
    public Result selectPage_2() {
        try {
            String loginUid = request.getParameter("uid"); // 当前登录用户ID

            List<Map<String, Object>> records = diaryMapper.selectPage_2(
                    newPage(request.getParameter("page"), request.getParameter("limit"))).getRecords();
            for (Map<String, Object> record : records) {

//                String diaryId = String.valueOf(record.get("id"));
//
//                // 正确传入当前用户ID
//                Map<String, Object> detail = diaryMapper.selectData(diaryId, loginUid);
//
//                // 获取点赞状态
//                Object praiseMy = detail.get("praise_my");
//
//                // ✅ 打印
//                System.out.println("动态ID：" + diaryId + "，当前用户是否点赞（praise_my）：" + praiseMy);
                //log.info(String.valueOf(record.get("id"))+" "+String.valueOf(record.get("uid")));
                //log.info(diaryMapper.selectData(String.valueOf(record.get("id")),String.valueOf(record.get("uid"))).toString());
                record.putAll(diaryMapper.selectData(String.valueOf(record.get("id")),String.valueOf(record.get("uid"))));
            }
            return Result.success(records);
//            return Result.success(diaryMapper.selectPage_2(
//                    newPage(request.getParameter("page"), request.getParameter("limit"))));
        } catch (Exception ignored) {
            log.error(ignored.getMessage());
        }
        return Result.failed("查询失败");
    }

    @Operation(summary = "分页查询社区动态")
    @Parameters({
            @Parameter(name = "page", description = "页码", required = true, example = "1"),
            @Parameter(name = "limit", description = "数量", required = true, example = "10"),
            @Parameter(name = "uid", description = "登录用户ID"),
            @Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true),
    })
    @GetMapping("selectPage_3")
    @ResponseBody
    public Result selectPage_3() {
        try {
            return Result.success(diaryMapper.selectPage_3(
                    newPage(request.getParameter("page"), request.getParameter("limit"))
            ,request.getParameter("uid")));
        } catch (Exception ignored) {
        }
        return Result.failed("查询失败");
    }

    @Operation(summary = "分页查询动态评论")
    @Parameters({
            @Parameter(name = "page", description = "页码", required = true, example = "1"),
            @Parameter(name = "limit", description = "数量", required = true, example = "10"),
            @Parameter(name = "fid", description = "动态ID", required = true),
            @Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true),
    })
    @GetMapping("selectPageComment")
    @ResponseBody
    public Result selectPageComment() {
        try {
            return Result.success(diaryMapper.selectPageComment(newPage(request.getParameter("page"), request.getParameter("limit")), request.getParameter("fid")));
        } catch (Exception ignored) {
        }
        return Result.failed("查询失败");
    }

    @Operation(summary = "点赞动态")
    @Parameters({
            @Parameter(name = "uid", description = "用户ID", required = true),
            @Parameter(name = "fid", description = "动态ID", required = true),
            @Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true),
    })
    @GetMapping("addPraise")
    @ResponseBody
    public Result addPraise() {
        int type = 1;
        try {
            if (diaryMapper.existsCollect(request.getParameter("uid"), request.getParameter("fid"), type) < 1) {
                Map<String, Object> map = new HashMap<>();
                map.put("uid", request.getParameter("uid"));
                map.put("fid", request.getParameter("fid"));
                map.put("type", type);
                map.put("comment", null);
                if (diaryMapper.insertCollect(map) > 0)
                    return Result.success("成功");
            }
        } catch (Exception ignored) {
        }
        return Result.failed("失败");
    }

    @Operation(summary = "随机获取社区动态列表（首页推荐）")
    @Parameters({
            @Parameter(name = "uid", description = "当前用户ID", required = true),
            @Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true),
    })
    @GetMapping("selectRandomCommunityList")
    @ResponseBody
    public Result selectRandomCommunityList() {
        try {
            String uid = request.getParameter("uid");
            List<Map<String, Object>> list = diaryMapper.selectRandomCommunityList(uid);
            return Result.success(list);
        } catch (Exception e) {
            log.error("随机社区动态查询失败", e);
            return Result.failed("查询失败");
        }
    }


    @Operation(summary = "评论动态")
    @Parameters({
            @Parameter(name = "uid", description = "用户ID", required = true),
            @Parameter(name = "fid", description = "动态ID", required = true),
            @Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true),
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(description = "body参数：评论内容：comment", required = true)
    @PostMapping("addComment")
    @ResponseBody
    public Result addComment(@RequestBody JSONObject body) {
        int type = 2;
        try {
            Map<String, Object> map = new HashMap<>();
            map.put("uid", request.getParameter("uid"));
            map.put("fid", request.getParameter("fid"));
            map.put("type", type);
            map.put("comment", body.getStr("comment"));
            if (diaryMapper.insertCollect(map) > 0)
                return Result.success("成功");
        } catch (Exception ignored) {
        }
        return Result.failed("失败");
    }

    @Operation(summary = "取消动态点赞")
    @Parameters({
            @Parameter(name = "uid", description = "用户ID", required = true),
            @Parameter(name = "fid", description = "动态ID", required = true),
            @Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true),
    })
    @GetMapping("delPraise")
    @ResponseBody
    public Result delPraise() {
        int type = 1;
        try {
            if (diaryMapper.existsCollect(request.getParameter("uid"), request.getParameter("fid"), type) > 0) {
                if (diaryMapper.deleteCollect(request.getParameter("uid"), request.getParameter("fid"), type) > 0)
                    return Result.success("成功");
            }
        } catch (Exception ignored) {
        }
        return Result.failed("失败");
    }

}
