package com.lmoflife.controller;

import cn.hutool.core.util.CharsetUtil;
import cn.hutool.core.util.RandomUtil;
import cn.hutool.core.util.ReUtil;
import cn.hutool.crypto.digest.DigestUtil;
import cn.hutool.extra.servlet.JakartaServletUtil;
import cn.hutool.json.JSONObject;
import com.lmoflife.pojo.Result;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.Resource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Tag(name = "登录、注册")
@Controller
@RequestMapping("login")
@Transactional(rollbackFor = Exception.class)
public class LoginController extends BaseController {

    private final String table = "user";
    @Resource
    JavaMailSender javaMailSender;

    @Operation(summary = "用户登录", description = "注：邮箱或手机号码任传一样")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(description = "body参数：邮箱：email，手机号：phone，密码：pwd", required = true)
    @PostMapping("")
    @ResponseBody
    public Result login(@RequestBody JSONObject body) {
        try {
            final String email = body.getStr("email");
            final String phone = body.getStr("phone");
            final String pwd = body.getStr("pwd");
            if (ObjectUtils.isEmpty(pwd) || (ObjectUtils.isEmpty(email) && ObjectUtils.isEmpty(phone)))
                return Result.failed("参数错误");
            Map<String, Object> user = commonMapper.selectData(table, !ObjectUtils.isEmpty(email) ? "email" : "phone", !ObjectUtils.isEmpty(email) ? email : phone);
            if (ObjectUtils.isEmpty(user)) return Result.failed("未注册");
            else if (!DigestUtil.md5Hex(pwd).equals(user.get("pwd"))) return Result.failed("密码错误");
            else {
                String token = RandomUtil.randomString(10);
                while (commonMapper.exists(table, "token", token) > 0) token = RandomUtil.randomString(10);
                commonMapper.edit(table, "token", token, !ObjectUtils.isEmpty(email) ? "email" : "phone", !ObjectUtils.isEmpty(email) ? email : phone);
                commonMapper.edit(table, "login", new Date(), !ObjectUtils.isEmpty(email) ? "email" : "phone", !ObjectUtils.isEmpty(email) ? email : phone);
                return Result.success("登录成功", commonMapper.selectData(table, "token", token));
            }
        } catch (Exception ignored) {
        }
        return Result.failed("发送失败");
    }

    @Operation(summary = "用户注册")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(description = "body参数：邮箱：email，手机号：phone，密码：pwd，验证码：verify", required = true)
    @PostMapping("signup")
    @ResponseBody
    public Result signup(@RequestBody JSONObject body) {
        try {
            final String email = body.getStr("email");
            final String phone = body.getStr("phone");
            final String pwd = body.getStr("pwd");
            final String verify = body.getStr("verify");
            if (ObjectUtils.isEmpty(pwd) || ObjectUtils.isEmpty(email)
                    || ObjectUtils.isEmpty(phone) || ObjectUtils.isEmpty(verify))
                return Result.failed("参数错误");
            if (commonMapper.exists(table, "email", email) > 0 || commonMapper.exists(table, "phone", phone) > 0)
                return Result.failed("邮箱或手机号已注册");
            final Map<String, Object> emp = userMapper.selectVerify(verify);
            if (ObjectUtils.isEmpty(emp) || !emp.get("email").equals(email)) return Result.failed("验证码无效");

            String id = RandomUtil.randomString(10);
            while (commonMapper.exists(table, "id", id) > 0) id = RandomUtil.randomString(10);
            String token = RandomUtil.randomString(10);
            while (commonMapper.exists(table, "token", token) > 0) token = RandomUtil.randomString(10);

            Map<String, Object> map = new HashMap<>();
            map.put("id", id);
            map.put("name", email);
            map.put("email", email);
            map.put("phone", phone);
            map.put("pwd", DigestUtil.md5Hex(pwd));
            map.put("token", token);
            if (userMapper.insert(map) > 0)
                return Result.success("注册成功，已登录", commonMapper.selectData(table, "id", id));
        } catch (Exception ignored) {
        }
        return Result.failed("失败");
    }

    @Operation(summary = "重置密码（忘记密码）")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(description = "body参数：邮箱：email，新密码：pwd，验证码：verify", required = true)
    @PostMapping("resetPwd")
    @ResponseBody
    public Result resetPwd(@RequestBody JSONObject body) {
        try {
            final String email = body.getStr("email");
            final String pwd = body.getStr("pwd");
            final String verify = body.getStr("verify");
            if (ObjectUtils.isEmpty(pwd) || ObjectUtils.isEmpty(email) || ObjectUtils.isEmpty(verify))
                return Result.failed("参数错误");

            final Map<String, Object> emp = userMapper.selectVerify(verify);
            if (ObjectUtils.isEmpty(emp) || !emp.get("email").equals(email)) return Result.failed("验证码无效");

            if (commonMapper.edit(table, "pwd", DigestUtil.md5Hex(pwd), "email", email) > 0)
                return Result.success("成功");
        } catch (Exception ignored) {
        }
        return Result.failed("失败");
    }

    @Operation(summary = "发送验证码", parameters = {@Parameter(name = "email", description = "邮箱", required = true)})
    @GetMapping("sendVerify")
    @ResponseBody
    public Result sendVerify() {
        try {
            System.out.println("====================");
            //测试
            final String email = request.getParameter("email");
            if (ObjectUtils.isEmpty(email) || !ReUtil.isMatch(ReUtilEmail, email))
                return Result.failed("邮箱错误");
            commonMapper.delete("verify", "email", email);
            String code = RandomUtil.randomNumbers(6);//生成验证码
            while (commonMapper.exists("verify", "code", code) > 0) code = RandomUtil.randomNumbers(6);

            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(mailUsername);
            message.setSubject("邮箱安全验证");
            message.setTo(email);
            message.setText("您正在进行邮箱验证，本次验证码为： " + code + "\n" +
                    "为了保障您帐号的安全性，请在10分钟内完成验证。");
            javaMailSender.send(message);
            //System.err.println(code);

            String id = RandomUtil.randomString(10);
            while (commonMapper.exists("verify", "id", id) > 0) id = RandomUtil.randomString(10);
            Map<String, Object> map = new HashMap<>();
            map.put("id", id);
            map.put("code", code);
            map.put("email", email);
            if (userMapper.insertVerify(map) > 0)
                return Result.success("验证码已发送");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Result.failed("发送失败");
    }

    @Parameters({@Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true)})
    @Operation(summary = "获取登录用户信息", parameters = {@Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true)})
    @GetMapping("loginUser")
    @ResponseBody
    public Result loginUser() {
        try {
            final String token = JakartaServletUtil.getHeader(request, cookieName, CharsetUtil.UTF_8);
            if (!ObjectUtils.isEmpty(token))
                return Result.success(commonMapper.selectData(table, "token", token));
        } catch (Exception ignored) {
        }
        return Result.failed("查询失败");
    }

    @Hidden
    @GetMapping("notLogin")
    @ResponseBody
    public Result notLogin() {
        return Result.notLogin();
    }

    @Hidden
    @GetMapping("notPermission")
    @ResponseBody
    public Result notPermission() {
        return Result.notPermission();
    }

}
