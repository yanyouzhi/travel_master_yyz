package com.lmoflife.config;

import com.lmoflife.controller.BaseController;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfiguration extends BaseController implements WebMvcConfigurer {

    //拦截器配置
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        InterceptorRegistration loginRegistry = registry.addInterceptor(getSessionInterceptor());
        loginRegistry.excludePathPatterns("/login");
        loginRegistry.excludePathPatterns("/login/signup");
        loginRegistry.excludePathPatterns("/login/resetPwd");
        loginRegistry.excludePathPatterns("/login/sendVerify");
        loginRegistry.excludePathPatterns("/login/notLogin");
        loginRegistry.excludePathPatterns("/login/notPermission");
        loginRegistry.excludePathPatterns("/swagger-ui/**");
        loginRegistry.excludePathPatterns("/v3/**");
        loginRegistry.addPathPatterns("/**");
    }

    @Bean
    public LoginInterceptor getSessionInterceptor() {
        return new LoginInterceptor();
    }

    //跨域支持
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**") // 所有接口
                .allowCredentials(false) // 是否发送 Cookie
                .allowedOriginPatterns("*"); // 支持域
        // .allowedMethods(new String[]{"GET", "POST", "PUT", "DELETE"}) // 支持方法
        // .allowedHeaders("*")
        // .exposedHeaders("*");
    }

    public class LoginInterceptor implements HandlerInterceptor {

        //拦截处理
        @Override
        public boolean preHandle(HttpServletRequest req, HttpServletResponse res, Object handler) {
            /*try {
                String token = req.getHeader(cookieName);
                if (!ObjectUtils.isEmpty(token) && commonMapper.exists("user", "token", token) > 0)
                    return true;
                req.getRequestDispatcher("/login/notLogin").forward(req, res);
            } catch (Exception e) {
                e.printStackTrace();
            }*/
            return true;
        }
    }
}
