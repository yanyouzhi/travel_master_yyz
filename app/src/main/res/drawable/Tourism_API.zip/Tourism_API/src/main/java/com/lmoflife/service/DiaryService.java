package com.lmoflife.service;

import cn.hutool.core.util.RandomUtil;
import cn.hutool.json.JSONObject;
import com.lmoflife.mapper.DiaryMapper;
import com.lmoflife.utils.OssUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * DiaryService 提供对动态相关业务逻辑的封装与抽象，保障业务处理的清晰与可维护性。
 * 注意：当前版本的实现以辅助控制层为主，未完全剥离 Controller 中的业务逻辑。
 */
@Service
@RequiredArgsConstructor
public class DiaryService {

    private final DiaryMapper diaryMapper;
    private final OssUtil ossUtil;
    private final String table = "diary";

    /**
     * 处理上传图片并返回 OSS 链接
     */
    public String handleImageUpload(String base64Image) {
        if (ObjectUtils.isEmpty(base64Image)) return null;
        return ossUtil.uploadBase64(base64Image);
    }

    /**
     * 查询动态详情
     */
    public Map<String, Object> getDiaryDetail(String id, String uid) {
        return diaryMapper.selectData(id, uid);
    }

    /**
     * 查询社区推荐动态
     */
    public List<Map<String, Object>> getRandomCommunityList(String uid) {
        return diaryMapper.selectRandomCommunityList(uid);
    }

    /**
     * 添加评论或点赞
     */
    public boolean insertCollect(String uid, String fid, int type, String comment) {
        Map<String, Object> map = new HashMap<>();
        map.put("uid", uid);
        map.put("fid", fid);
        map.put("type", type);
        map.put("comment", comment);
        return diaryMapper.insertCollect(map) > 0;
    }

    // 可继续添加分页查询、点赞取消、删除等接口方法，略作包装
}
