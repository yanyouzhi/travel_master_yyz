package com.lmoflife.controller;

import cn.hutool.crypto.digest.DigestUtil;
import cn.hutool.json.JSONObject;
import com.lmoflife.pojo.Result;
import com.lmoflife.utils.OssUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@Tag(name = "用户")
@Controller
@RequestMapping("user")
@Transactional(rollbackFor = Exception.class)
public class UserController extends BaseController {

    private final String table = "user";

    private final OssUtil ossUtil;
    public UserController(OssUtil ossUtil) {
        this.ossUtil = ossUtil;
    }

    @Operation(summary = "用户信息查询")
    @Parameters({
            @Parameter(name = "id", description = "用户ID", required = true),
            @Parameter(name = "uid", description = "当前登录用户ID", required = true),
            @Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true),
    })
    @GetMapping("selectData")
    @ResponseBody
    public Result selectData() {
        try {
            return Result.success(userMapper.selectData(request.getParameter("id"), request.getParameter("uid")));
        } catch (Exception ignored) {
        }
        return Result.failed("查询失败");
    }

    @Operation(summary = "分页查询关注列表（我关注的）")
    @Parameters({
            @Parameter(name = "page", description = "页码", required = true, example = "1"),
            @Parameter(name = "limit", description = "数量", required = true, example = "10"),
            @Parameter(name = "uid", description = "用户ID", required = true),
            @Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true),
    })
    @GetMapping("selectPageCollect")
    @ResponseBody
    public Result selectPageCollect() {
        try {
            return Result.success(userMapper.selectPageCollect(newPage(request.getParameter("page"), request.getParameter("limit")), request.getParameter("uid")));
        } catch (Exception ignored) {
        }
        return Result.failed("查询失败");
    }

    @Operation(summary = "分页查询关注列表（关注我的）")
    @Parameters({
            @Parameter(name = "page", description = "页码", required = true, example = "1"),
            @Parameter(name = "limit", description = "数量", required = true, example = "10"),
            @Parameter(name = "uid", description = "用户ID", required = true),
            @Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true),
    })
    @GetMapping("selectPageFan")
    @ResponseBody
    public Result selectPageFan() {
        try {
            return Result.success(userMapper.selectPageFan(newPage(request.getParameter("page"), request.getParameter("limit")), request.getParameter("uid")));
        } catch (Exception ignored) {
        }
        return Result.failed("查询失败");
    }

    @Operation(summary = "修改登录密码")
    @Parameters({@Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true)})
    @io.swagger.v3.oas.annotations.parameters.RequestBody(description = "body参数：用户ID：uid，原密码：pwd，新密码：newPwd", required = true)
    @PostMapping("editPwd")
    @ResponseBody
    public Result editPwd(@RequestBody JSONObject body) {
        try {
            final String uid = body.getStr("uid");
            final String pwd = body.getStr("pwd");
            final String newPwd = body.getStr("newPwd");
            if (ObjectUtils.isEmpty(pwd) || ObjectUtils.isEmpty(newPwd) || ObjectUtils.isEmpty(uid))
                return Result.failed("参数错误");
            final Map<String, Object> user = commonMapper.selectData(table, "id", uid);
            if (!DigestUtil.md5Hex(pwd).equals(user.get("pwd"))) return Result.failed("密码错误");
            else if (commonMapper.edit(table, "pwd", DigestUtil.md5Hex(newPwd), "id", uid) > 0)
                return Result.success("成功");
        } catch (Exception ignored) {
        }
        return Result.failed("失败");
    }

    @Operation(summary = "修改手机号")
    @Parameters({@Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true)})
    @io.swagger.v3.oas.annotations.parameters.RequestBody(description = "body参数：用户ID：uid，新号码：phone", required = true)
    @PostMapping("editPhone")
    @ResponseBody
    public Result editPhone(@RequestBody JSONObject body) {
        try {
            final String uid = body.getStr("uid");
            final String phone = body.getStr("phone");
            if (ObjectUtils.isEmpty(phone) || ObjectUtils.isEmpty(uid))
                return Result.failed("参数错误");
            if (commonMapper.exists(table, "phone", phone) > 0) return Result.failed("号码已注册");
            else if (commonMapper.edit(table, "phone", phone, "id", uid) > 0)
                return Result.success("成功");
        } catch (Exception ignored) {
        }
        return Result.failed("失败");
    }

    @Operation(summary = "修改邮箱")
    @Parameters({@Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true)})
    @io.swagger.v3.oas.annotations.parameters.RequestBody(description = "body参数：用户ID：uid，新邮箱：email，验证码：verify", required = true)
    @PostMapping("editEmail")
    @ResponseBody
    public Result editEmail(@RequestBody JSONObject body) {
        try {
            final String email = body.getStr("email");
            final String uid = body.getStr("uid");
            final String verify = body.getStr("verify");
            if (ObjectUtils.isEmpty(uid) || ObjectUtils.isEmpty(email) || ObjectUtils.isEmpty(verify))
                return Result.failed("参数错误");
            if (commonMapper.exists(table, "email", email) > 0) return Result.failed("邮箱已注册");
            final Map<String, Object> emp = userMapper.selectVerify(verify);
            final Map<String, Object> user = commonMapper.selectData(table, "id", uid);
            if (ObjectUtils.isEmpty(emp) || !emp.get("email").equals(user.get("email")))
                return Result.failed("验证码无效");
            if (commonMapper.edit(table, "email", email, "id", uid) > 0)
                return Result.success("成功");
        } catch (Exception ignored) {
        }
        return Result.failed("失败");
    }

    @Operation(summary = "修改用户资料")
    @Parameters({@Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true)})
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "body参数：用户ID：uid，名称：name，头像图片（Base64字符串）：photo，性别（1：男，2：女）：sex，地址：addr，签名：description，职业：occupation，联系方式：contact", required = true)
    @PostMapping("editUserInfo")
    @ResponseBody
    public Result editUserInfo(@RequestBody JSONObject body) {
        try {
            if (ObjectUtils.isEmpty(body.getStr("uid"))
                    || ObjectUtils.isEmpty(body.getStr("name"))
                    || ObjectUtils.isEmpty(body.getStr("photo"))
                    || ObjectUtils.isEmpty(body.getStr("sex")))
                return Result.failed("参数错误");

            // 处理 photo，上传到 OSS
            String base64Photo = body.getStr("photo");
            System.out.println(base64Photo);
            String photoUrl = ossUtil.uploadBase64(base64Photo);
            body.set("photo", photoUrl); // 替换 photo 为 OSS URL

            if (userMapper.editUserInfo(body) > 0)
                return Result.success("成功");
        } catch (Exception ignored) {
        }
        return Result.failed("失败");
    }


    @Operation(summary = "关注用户")
    @Parameters({
            @Parameter(name = "uid", description = "当前登录用户ID", required = true),
            @Parameter(name = "fid", description = "要关注的用户ID", required = true),
            @Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true),
    })
    @PostMapping("follow")
    @ResponseBody
    public Result followUser(@RequestParam String uid, @RequestParam String fid) {
        try {
            // 判断是否已关注
            if (userMapper.isFollowing(fid, uid) > 0) {
                return Result.failed("已关注该用户");
            }

            if (userMapper.followUser(fid, uid) > 0) {
                return Result.success("关注成功");
            }
        } catch (Exception ignored) {
        }
        return Result.failed("关注失败");
    }

    @Operation(summary = "取消关注用户")
    @Parameters({
            @Parameter(name = "uid", description = "当前登录用户ID", required = true),
            @Parameter(name = "fid", description = "要取消关注的用户ID", required = true),
            @Parameter(name = "TOKEN", in = ParameterIn.HEADER, required = true),
    })
    @PostMapping("unfollow")
    @ResponseBody
    public Result unfollowUser(@RequestParam String uid, @RequestParam String fid) {
        try {
            if (userMapper.unfollowUser(fid, uid) > 0) {
                return Result.success("取消关注成功");
            }
        } catch (Exception ignored) {
        }
        return Result.failed("取消关注失败");
    }



}
